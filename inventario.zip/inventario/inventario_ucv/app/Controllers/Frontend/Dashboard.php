<?php namespace App\Controllers\Frontend;

class Dashboard extends BaseController {

	public function index() {
		$this->data['route'] = 'dashboard';

		$this->applyUpdates();

		if($this->logged_user->role == 'admin' || $this->logged_user->role == 'supervisor')
			return view('dashboard', $this->data);
		else
			return view('worker_dashboard', $this->data);
	}

	private function applyUpdates() {
		// If current version is < 1.0.4, apply 1.0.4 update
		$currentVersion = $this->data['settings']->version;

		if($currentVersion == '1.0.0' || $currentVersion == '1.0.1' || $currentVersion == '1.0.2' || $currentVersion == '1.0.3')
			$this->data['settings']->version = $this->_apply_104_update();
	}

	private function _apply_104_update() {
		$this->settings->set('val', '1.0.4')->where('name', 'version')->update();

		return '1.0.4';
	}
}