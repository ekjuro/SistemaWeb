<?php namespace App\Models;

use App\Libraries\JsonGrouper;
use CodeIgniter\Model;

class AlertsModel extends Model {
	protected $table = 'inventario_alerts';
	protected $primaryKey = 'id';

	protected $returnType = 'object';
	protected $allowedFields = [
		'id',
		'item_id',
		'warehouse_id',
		'type',
		'alert_qty',
		'created_at',
		'updated_at'
	];

	protected $useTimestamps = true;
	protected $createdField = 'created_at';
	protected $updatedField = 'updated_at';

	// DataTables parameters
	private $dtSearch;
	private $dtOrderBy;
	private $dtOrderDir;
	private $dtLength;
	private $dtStart;

	// To load DataTables parameters
	public function setDtParameters($search, $orderBy, $orderDir, $length, $start) {
		$this->dtSearch = $search;
		$this->dtOrderBy = $orderBy;
		$this->dtOrderDir = $orderDir;
		$this->dtLength = $length;
		$this->dtStart = $start;
	}

	// To get all alerts -- Adapted to DataTables
	public function dtGetAllAlerts() {
		$recordsTotal = $this->select('inventario_alerts.*')->countAllResults();

		$alerts = $this
			->select('inventario_alerts.item_id AS DT_RowId,
								_item.name AS item_name,
								_warehouse.name AS warehouse_name,
								inventario_alerts.type,
								IF(inventario_alerts.type = "min", _item.min_alert, _item.max_alert) AS alert_qty,
								_quantity.quantity AS current_qty,
								inventario_alerts.created_at')
			->groupStart()
			->orLike('_item.name', $this->dtSearch)
			->orLike('_warehouse.name', $this->dtSearch)
			->groupEnd()
			->join('inventario_items AS _item', '_item.id = inventario_alerts.item_id', 'left')
			->join('inventario_warehouses AS _warehouse', '_warehouse.id = inventario_alerts.warehouse_id', 'left')
			->join('inventario_quantities AS _quantity', '_quantity.item_id = inventario_alerts.item_id AND _quantity.warehouse_id = inventario_alerts.warehouse_id', 'left')
			->orderBy($this->dtOrderBy, $this->dtOrderDir)
			->limit($this->dtLength, $this->dtStart)
			->groupBy('inventario_alerts.id');

		$recordsFiltered = $alerts->countAllResults(false);
		$data = $alerts->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	public function deleteAlertsForItem($itemId) {
		return $this->where('item_id', $itemId)->delete();
	}

	public function triggerMinAlert($itemId, $warehouseId, $minMaxQty) {
		return $this->insert([
			'item_id' => $itemId,
			'warehouse_id' => $warehouseId,
			'type' => 'min',
			'alert_qty' => $minMaxQty
		]);
	}

	public function triggerMaxAlert($itemId, $warehouseId, $minMaxQty) {
		return $this->insert([
			'item_id' => $itemId,
			'warehouse_id' => $warehouseId,
			'type' => 'max',
			'alert_qty' => $minMaxQty
		]);
	}

	// Get latest alerts, to be shown in the header
	public function getLatestAlertsForHeader() {
		$alerts = $this
			->select('inventario_alerts.item_id,
								inventario_alerts.warehouse_id,
								inventario_alerts.type,
								inventario_alerts.alert_qty,
								inventario_alerts.created_at,
								_item.name AS item_name,
								_item.min_alert AS item_min_alert,
								_item.max_alert AS item_max_alert,
								_warehouse.name AS warehouse_name,
								_quantity.quantity AS current_qty')
			->join('inventario_items AS _item', '_item.id = inventario_alerts.item_id', 'left')
			->join('inventario_warehouses AS _warehouse', '_warehouse.id = inventario_alerts.warehouse_id', 'left')
			->join('inventario_quantities AS _quantity', '_quantity.item_id = inventario_alerts.item_id AND _quantity.warehouse_id = inventario_alerts.warehouse_id', 'left')
			->groupBy('inventario_alerts.id')
			->limit(6)
			->find();

		if(!$alerts)
			return [];

		$grouper = new JsonGrouper(['item', 'warehouse'], $alerts);
		
		return $grouper->group();
	}
}