<?php namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model {
	protected $table = 'inventario_users';
	protected $primaryKey = 'id';

	protected $returnType = 'object';
	protected $allowedFields = [
		'id',
		'name',
		'username',
		'password',
		'email_address',
		'phone_number',
		'role',
		'created_at',
		'updated_at',
		'deleted_at'
	];

	protected $useTimestamps = true;
	protected $useSoftDeletes = true;
	protected $createdField = 'created_at';
	protected $updatedField = 'updated_at';
	protected $deletedField = 'deleted_at';

	// DataTables parameters
	private $dtSearch;
	private $dtOrderBy;
	private $dtOrderDir;
	private $dtLength;
	private $dtStart;

	// To load DataTables parameters
	public function setDtParameters($search, $orderBy, $orderDir, $length, $start) {
		$this->dtSearch = $search;
		$this->dtOrderBy = $orderBy;
		$this->dtOrderDir = $orderDir;
		$this->dtLength = $length;
		$this->dtStart = $start;
	}

	// To get all users -- Adapted to DataTables
	public function dtGetAllUsers() {
		$recordsTotal = $this
			->select('inventario_users.*')
			->countAllResults();

		$users = $this
			->select('inventario_users.id AS DT_RowId,
								name,
								username,
								email_address,
								phone_number,
								role,
								COUNT(_warehouse_relations.id) AS warehouses')
			->groupStart()
			->orLike('name', $this->dtSearch)
			->orLike('username', $this->dtSearch)
			->orLike('email_address', $this->dtSearch)
			->orLike('phone_number', $this->dtSearch)
			->orLike('role', $this->dtSearch)
			->groupEnd()
			->join('inventario_warehouse_relations AS _warehouse_relations', '_warehouse_relations.user_id = inventario_users.id', 'left')
			->orderBy($this->dtOrderBy, $this->dtOrderDir)
			->limit($this->dtLength, $this->dtStart)
			->groupBy('inventario_users.id');

		$recordsFiltered = $users->countAllResults(false);
		$data = $users->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	// To get a single user by ID
	public function getUser($id) {
		$user = $this
			->select('id,
								name,
								username,
								email_address,
								phone_number,
								role,
								created_at,
								updated_at')
			->where('inventario_users.id', $id)
			->first();

		if(!$user)
			return false;

		return $user;
	}

	// To get a single user by username
	public function getUserByUsername($username) {
		$user = $this
			->select('id,
								name,
								username,
								email_address,
								phone_number,
								role,
								created_at,
								updated_at')
			->where('inventario_users.username', $username)
			->first();

		if(!$user)
			return false;

		return $user;
	}

	// To get a single user by email address
	public function getUserByEmailAddress($email_address) {
		$user = $this
			->select('id,
								name,
								username,
								email_address,
								phone_number,
								role,
								created_at,
								updated_at')
			->where('inventario_users.email_address', $email_address)
			->first();

		if(!$user)
			return false;

		return $user;
	}

	// To get a list of workers that are NOT responsible of a given warehouse ID
	public function getWorkersNotResponsibleOfWarehouse($warehouseId) {
		$workers = $this
			->select('inventario_users.id AS id,
								inventario_users.name AS name,
								inventario_users.username AS username')
			->join('inventario_warehouse_relations AS _relation', "_relation.user_id = inventario_users.id AND _relation.warehouse_id = $warehouseId", 'left')
			->where('inventario_users.role', 'worker')
			->where('inventario_users.deleted_at is null')
			->where('_relation.user_id is null')
			->groupBy('inventario_users.id')
			->find();

		if(!$workers)
			return [];
		
		return $workers;
	}

	// To get a list of supervisors that are NOT responsible of a given warehouse ID
	public function getSupervisorsNotResponsibleOfWarehouse($warehouseId) {
		$supervisors = $this
			->select('inventario_users.id AS id,
								inventario_users.name AS name,
								inventario_users.username AS username')
			->join('inventario_warehouse_relations AS _relation', "_relation.user_id = inventario_users.id AND _relation.warehouse_id = $warehouseId", 'left')
			->where('inventario_users.role', 'supervisor')
			->where('inventario_users.deleted_at is null')
			->where('_relation.user_id is null')
			->groupBy('inventario_users.id')
			->find();

	if(!$supervisors)
		return [];
	
	return $supervisors;
	}
}