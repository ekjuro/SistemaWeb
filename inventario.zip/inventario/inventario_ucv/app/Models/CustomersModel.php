<?php namespace App\Models;

use App\Libraries\JsonGrouper;
use CodeIgniter\Model;

class CustomersModel extends Model {
	protected $table = 'inventario_customers';
	protected $primaryKey = 'id';

	protected $returnType = 'object';
	protected $allowedFields = [
		'id',
		'name',
		'internal_name',
		'company_name',
		'tax_number',
		'email_address',
		'phone_number',
		'address',
		'city',
		'country',
		'state',
		'zip_code',
		'custom_field1',
		'custom_field2',
		'custom_field3',
		'notes',
		'created_by',
		'created_at',
		'updated_at',
		'deleted_at'
	];

	protected $useTimestamps = true;
	protected $useSoftDeletes = true;
	protected $createdField = 'created_at';
	protected $updatedField = 'updated_at';
	protected $deletedField = 'deleted_at';
	
	// DataTables parameters
	private $dtSearch;
	private $dtOrderBy;
	private $dtOrderDir;
	private $dtLength;
	private $dtStart;

	// To load DataTables parameters
	public function setDtParameters($search, $orderBy, $orderDir, $length, $start) {
		$this->dtSearch = $search;
		$this->dtOrderBy = $orderBy;
		$this->dtOrderDir = $orderDir;
		$this->dtLength = $length;
		$this->dtStart = $start;
	}

	// To get all customers -- Adapted to DataTables
	public function dtGetAllCustomers() {
		$recordsTotal = $this
			->select('inventario_customers.*')
			->countAllResults();

		$customers = $this
			->select('inventario_customers.id AS DT_RowId,
								inventario_customers.name,
								inventario_customers.internal_name,
								inventario_customers.email_address,
								inventario_customers.phone_number,
								inventario_customers.tax_number')
			->groupStart()
			->orLike('inventario_customers.name', $this->dtSearch)
			->orLike('inventario_customers.internal_name', $this->dtSearch)
			->orLike('inventario_customers.company_name', $this->dtSearch)
			->orLike('inventario_customers.email_address', $this->dtSearch)
			->orLike('inventario_customers.phone_number', $this->dtSearch)
			->orLike('inventario_customers.tax_number', $this->dtSearch)
			->groupEnd()
			->orderBy($this->dtOrderBy, $this->dtOrderDir)
			->limit($this->dtLength, $this->dtStart)
			->groupBy('inventario_customers.id');

		$recordsFiltered = $customers->countAllResults(false);
		$data = $customers->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	// To get 5 most recent customers -- Without DataTables features
	// Results will vary depending on the user that is requesting
	// them (if $limitByWarehouses is true, we'll limit results to the
	// warehouse IDs provided in $warehouseIds)
	public function dtGetLatest(bool $limitByWarehouses = false, array $warehouseIds = []) {
		$data = $this
			->select('inventario_customers.id AS DT_RowId,
								inventario_customers.created_at,
								inventario_customers.name,
								inventario_customers.internal_name,
								inventario_customers.company_name,
								inventario_customers.email_address')
			->orderBy('inventario_customers.created_at', 'DESC')
			->limit(5);

		// Should we limit by warehouse?
		if($limitByWarehouses)
			$data = $this->restrictQueryByIds($data, 'inventario_customers.warehouse_id', $warehouseIds);

		$recordsFiltered = $data->countAllResults(false);
		$recordsTotal = $recordsFiltered;
		$data = $data->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	// To get a single customer by ID
	public function getCustomer($id) {
		$customer = $this
			->select('inventario_customers.id,
								inventario_customers.name,
								inventario_customers.internal_name,
								inventario_customers.company_name,
								inventario_customers.tax_number,
								inventario_customers.email_address,
								inventario_customers.phone_number,
								inventario_customers.address,
								inventario_customers.city,
								inventario_customers.country,
								inventario_customers.state,
								inventario_customers.zip_code,
								inventario_customers.custom_field1,
								inventario_customers.custom_field2,
								inventario_customers.custom_field3,
								inventario_customers.notes,
								inventario_customers.created_at,
								inventario_customers.updated_at,
								inventario_customers.created_by AS created_by_id,
								_user.name AS created_by_name')
			->join('inventario_users AS _user', '_user.id = inventario_customers.created_by', 'left')
			->where('inventario_customers.id', $id)
			->first();

		if(!$customer)
			return false;

		$grouper = new JsonGrouper('created_by', $customer);

		return $grouper->group();
	}

	// To get a single customer by name
	public function getCustomerByName($name) {
		$customer = $this
			->select('inventario_customers.id,
								inventario_customers.name,
								inventario_customers.internal_name,
								inventario_customers.company_name,
								inventario_customers.tax_number,
								inventario_customers.email_address,
								inventario_customers.phone_number,
								inventario_customers.address,
								inventario_customers.city,
								inventario_customers.country,
								inventario_customers.state,
								inventario_customers.zip_code,
								inventario_customers.custom_field1,
								inventario_customers.custom_field2,
								inventario_customers.custom_field3,
								inventario_customers.notes,
								inventario_customers.created_at,
								inventario_customers.updated_at,
								inventario_customers.created_by AS created_by_id,
								_user.name AS created_by_name')
			->join('inventario_users AS _user', '_user.id = inventario_customers.created_by', 'left')
			->where('inventario_customers.name', $name)
			->first();

		if(!$customer)
			return false;

		$grouper = new JsonGrouper('created_by', $customer);

		return $grouper->group();
	}

	// To get a single customer by internal name
	public function getCustomerByInternalName($internalName) {
		$customer = $this
			->select('inventario_customers.id,
								inventario_customers.name,
								inventario_customers.internal_name,
								inventario_customers.company_name,
								inventario_customers.tax_number,
								inventario_customers.email_address,
								inventario_customers.phone_number,
								inventario_customers.address,
								inventario_customers.city,
								inventario_customers.country,
								inventario_customers.state,
								inventario_customers.zip_code,
								inventario_customers.custom_field1,
								inventario_customers.custom_field2,
								inventario_customers.custom_field3,
								inventario_customers.notes,
								inventario_customers.created_at,
								inventario_customers.updated_at,
								inventario_customers.created_by AS created_by_id,
								_user.name AS created_by_name')
			->join('inventario_users AS _user', '_user.id = inventario_customers.created_by', 'left')
			->where('inventario_customers.internal_name', $internalName)
			->first();

		if(!$customer)
			return false;

		$grouper = new JsonGrouper('created_by', $customer);

		return $grouper->group();
	}

	// To get a list of customers (id and name), primarily to be displayed in a select
	public function getCustomersList() {
		$customers = $this->select('id, name')->find();

		if(!$customers)
			return [];

		return $customers;
	}

	/**
	 * This function will restrict a query, so that $column only has
	 * the values provided in the $ids array
	 */
	private function restrictQueryByIds($query, string $column, array $ids) {
		if(count($ids) == 0)
			$query->where('1=0', null, false);
		else{
			$query->groupStart();
			foreach($ids as $id)
				$query->orWhere($column, $id);
			$query->groupEnd();
		}

		return $query;
	}
}