<?php namespace App\Models;

use App\Libraries\JsonGrouper;
use CodeIgniter\Model;

class SalesModel extends Model {
	protected $table = 'inventario_sales';
	protected $primaryKey = 'id';

	protected $returnType = 'object';
	protected $allowedFields = [
		'id',
		'reference',
		'customer_id',
		'warehouse_id',
		'items',
		'n_items',
		'shipping_cost',
		'discount',
		'discount_type',
		'tax',
		'subtotal',
		'grand_total',
		'created_by',
		'created_at',
		'confirmed_at',
		'updated_at',
		'notes',
		'deleted_at'
	];

	protected $useTimestamps = true;
	protected $useSoftDeletes = true;
	protected $createdField = 'created_at';
	protected $updatedField = 'updated_at';
	protected $deletedField = 'deleted_at';

	// DataTables parameters
	private $dtSearch;
	private $dtOrderBy;
	private $dtOrderDir;
	private $dtLength;
	private $dtStart;

	// To load DataTables parameters
	public function setDtParameters($search, $orderBy, $orderDir, $length, $start) {
		$this->dtSearch = $search;
		$this->dtOrderBy = $orderBy;
		$this->dtOrderDir = $orderDir;
		$this->dtLength = $length;
		$this->dtStart = $start;
	}

	// To get all sales -- Adapted to DataTables
	// Results will vary depending on the user that is requesting
	// them (if $limitByWarehouses is true, we'll limit results to the
	// warehouse IDs provided in $warehouseIds)
	public function dtGetAllSales(bool $limitByWarehouses = false, array $warehouseIds = []) {
		$recordsTotal = $this->select('inventario_sales.*');

		// Should we limit by warehouses? (If user is worker/supervisor)
		if($limitByWarehouses)
			$recordsTotal = $this->restrictQueryByIds($recordsTotal, 'inventario_sales.warehouse_id', $warehouseIds);

		$recordsTotal = $recordsTotal->countAllResults();

		$sales = $this
			->select('inventario_sales.id AS DT_RowId,
								inventario_sales.reference,
								_warehouse.name AS warehouse_name,
								inventario_sales.created_at,
								_customer.name AS customer_name,
								inventario_sales.grand_total')
			->groupStart()
			->orLike('inventario_sales.reference', $this->dtSearch)
			->orLike('_warehouse.name', $this->dtSearch)
			->orLike('_customer.name', $this->dtSearch)
			->groupEnd()
			->join('inventario_warehouses AS _warehouse', '_warehouse.id = inventario_sales.warehouse_id', 'left')
			->join('inventario_customers AS _customer', '_customer.id = inventario_sales.customer_id', 'left')
			->orderBy($this->dtOrderBy, $this->dtOrderDir)
			->limit($this->dtLength, $this->dtStart)
			->groupBy('inventario_sales.id');

		// Should we limit by warehouse?
		if($limitByWarehouses)
			$sales = $this->restrictQueryByIds($sales, 'inventario_sales.warehouse_id', $warehouseIds);

		$recordsFiltered = $sales->countAllResults(false);
		$data = $sales->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	// To get 5 most recent sales -- Without DataTables features
	// Results will vary depending on the user that is requesting
	// them (if $limitByWarehouses is true, we'll limit results to the
	// warehouse IDs provided in $warehouseIds)
	public function dtGetLatest(bool $limitByWarehouses = false, array $warehouseIds = []) {
		$data = $this
			->select('inventario_sales.id AS DT_RowId,
								inventario_sales.created_at,
								inventario_sales.reference,
								_customer.name AS customer_name,
								inventario_sales.grand_total')
			->join('inventario_sales_returns AS _return', '_return.sale_id = inventario_sales.id', 'left')
			->join('inventario_customers AS _customer', '_customer.id = inventario_sales.customer_id', 'left')
			->groupBy('inventario_sales.id')
			->orderBy('inventario_sales.created_at', 'DESC')
			->limit(5);

		// Should we limit by warehouse?
		if($limitByWarehouses)
			$data = $this->restrictQueryByIds($data, 'inventario_sales.warehouse_id', $warehouseIds);

		$recordsFiltered = $data->countAllResults(false);
		$recordsTotal = $recordsFiltered;
		$data = $data->find();

		return [
			'recordsTotal' => $recordsTotal,
			'recordsFiltered' => $recordsFiltered,
			'data' => $data
		];
	}

	// To get a single sale by ID
	public function getSale($id) {
		$sale = $this
			->select('inventario_sales.id,
								inventario_sales.reference,
								inventario_sales.items,
								inventario_sales.shipping_cost,
								inventario_sales.discount,
								inventario_sales.discount_type,
								inventario_sales.tax,
								inventario_sales.subtotal,
								inventario_sales.notes,
								inventario_sales.grand_total,
								inventario_sales.created_at,
								inventario_sales.updated_at,
								inventario_sales.created_by AS created_by_id,
								_user.name AS created_by_name,
								_customer.id AS customer_id,
								_customer.name AS customer_name,
								_customer.address AS customer_address,
								_customer.city AS customer_city,
								_customer.state AS customer_state,
								_customer.zip_code AS customer_zip_code,
								_customer.country AS customer_country,
								_warehouse.id AS warehouse_id,
								_warehouse.name AS warehouse_name,
								_return.id AS return_id')
			->join('inventario_users AS _user', '_user.id = inventario_sales.created_by', 'left')
			->join('inventario_customers AS _customer', '_customer.id = inventario_sales.customer_id', 'left')
			->join('inventario_warehouses AS _warehouse', '_warehouse.id = inventario_sales.warehouse_id', 'left')
			->join('inventario_sales_returns AS _return', '_return.sale_id = inventario_sales.id', 'left')
			->where('inventario_sales.id', $id)
			->groupBy('inventario_sales.id')
			->first();

		if(!$sale)
			return false;

		$grouper = new JsonGrouper(['created_by', 'customer', 'warehouse'], $sale);
		$grouped = $grouper->group();

		$grouped->items = json_decode($grouped->items);

		return $grouped;
	}

	public function getSaleByReference($reference) {
		$sale = $this
			->select('inventario_sales.id,
								inventario_sales.reference,
								inventario_sales.items,
								inventario_sales.shipping_cost,
								inventario_sales.discount,
								inventario_sales.discount_type,
								inventario_sales.tax,
								inventario_sales.subtotal,
								inventario_sales.notes,
								inventario_sales.grand_total,
								inventario_sales.created_at,
								inventario_sales.updated_at,
								inventario_sales.created_by AS created_by_id,
								_user.name AS created_by_name,
								_customer.id AS customer_id,
								_customer.name AS customer_name,
								_customer.address AS customer_address,
								_customer.city AS customer_city,
								_customer.state AS customer_state,
								_customer.zip_code AS customer_zip_code,
								_customer.country AS customer_country,
								_warehouse.id AS warehouse_id,
								_warehouse.name AS warehouse_name,
								_return.id AS return_id')
			->join('inventario_users AS _user', '_user.id = inventario_sales.created_by', 'left')
			->join('inventario_customers AS _customer', '_customer.id = inventario_sales.customer_id', 'left')
			->join('inventario_warehouses AS _warehouse', '_warehouse.id = inventario_sales.warehouse_id', 'left')
			->join('inventario_sales_returns AS _return', '_return.sale_id = inventario_sales.id', 'left')
			->where('inventario_sales.reference', $reference)
			->groupBy('inventario_sales.id')
			->first();

		if(!$sale)
			return false;

		$grouper = new JsonGrouper(['created_by', 'customer', 'warehouse'], $sale);
		$grouped = $grouper->group();

		$grouped->items = json_decode($grouped->items);

		return $grouped;
	}

	// To get stats for sales
	// Results will vary depending on the user that is requesting
	// them (if $limitByWarehouses is true, we'll limit results to the
	// warehouse IDs provided in $warehouseIds)
	public function statSales($fromDate, $toDate, bool $limitByWarehouses = false, array $warehouseIds = []) {
		$sales = $this
			->selectSum('grand_total')
			->where("created_at BETWEEN '{$fromDate} 00:00:00' AND '{$toDate} 23:59:59'")
			->groupBy('inventario_sales.id');

		if($limitByWarehouses)
			$sales = $this->restrictQueryByIds($sales, 'inventario_sales.warehouse_id', $warehouseIds);

		$sales = $sales->first();

		return (!$sales) ? 0 : $sales->grand_total;
	}

	// To get stats for sales, to be graphed, with range (between date A and date B)
	public function statSalesForGraphWithRange($fromDate, $toDate, bool $limitByWarehouses = false, array $warehouseIds = []) {
		$sales = $this
			->select("SUM(inventario_sales.grand_total) AS grand_total,
								DATE_FORMAT(inventario_sales.created_at, '%Y-%m-%d') AS created_at")
			->where("inventario_sales.created_at BETWEEN '{$fromDate} 00:00:00' AND '{$toDate} 23:59:59'")
			->groupBy('DAY(inventario_sales.created_at)');

		if($limitByWarehouses)
			$sales = $this->restrictQueryByIds($sales, 'inventario_sales.warehouse_id', $warehouseIds);

		$sales = $sales->find();

		return (!$sales) ? [] : $sales;
	}

	// To get stats for sales, to be graphed, with year
	public function statSalesForGraphWithYear($year, bool $limitByWarehouses = false, array $warehouseIds = []) {
		$sales = $this
			->select("SUM(inventario_sales.grand_total) AS grand_total,
								DATE_FORMAT(inventario_sales.created_at, '%Y-%m') AS created_at")
			->where("YEAR(inventario_sales.created_at) = '{$year}'")
			->groupBy('MONTH(inventario_sales.created_at)');

		if($limitByWarehouses)
			$sales = $this->restrictQueryByIds($sales, 'inventario_sales.warehouse_id', $warehouseIds);

		$sales = $sales->find();

		return (!$sales) ? [] : $sales;
	}

	/**
	 * This function will restrict a query, so that $column only has
	 * the values provided in the $ids array
	 */
	private function restrictQueryByIds($query, string $column, array $ids) {
		if(count($ids) == 0)
			$query->where('1=0', null, false);
		else{
			$query->groupStart();
			foreach($ids as $id)
				$query->orWhere($column, $id);
			$query->groupEnd();
		}

		return $query;
	}
}