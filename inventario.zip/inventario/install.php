<?php
$ucv_version = '1.0.4';
$messages = [];

// Comprobar la versión de PHP (> 7.4)
$requiredVersion = '7.4';
$currentVersion = PHP_VERSION;
if(version_compare($currentVersion, $requiredVersion) < 0) {
	$messages[] = "Su versión de PHP debe ser <strong>{$requiredVersion}</strong> o posterior, y su versión actual es {$currentVersion}. La instalación no puede continuar hasta que actualice su versión de PHP.";
	return renderPage($messages);
}

// extensiones
if(!extension_loaded('intl'))
	$messages[] = "Su servidor no tiene instalada la extensión <strong>intl</strong>, necesaria para instalar Inventario - UCV. Instale y habilite esta extensión antes de continuar.";

if(!extension_loaded('mbstring'))
	$messages[] = "Su servidor no tiene instalada la extensión <strong>mbstring</strong>, necesaria para instalar Inventario - UCV. Instale y habilite esta extensión antes de continuar.";

if(!extension_loaded('json'))
	$messages[] = "Su servidor no tiene instalada la extensión <strong>php-json</strong>, necesaria para instalar Inventario - UCV. Instale y habilite esta extensión antes de continuar.";

if(!extension_loaded('mysqlnd'))
	$messages[] = "Su servidor no tiene instalada la extensión <strong>php-mysqlnd</strong>, necesaria para instalar Inventario - UCV. Instale y habilite esta extensión antes de continuar.";

if(!extension_loaded('xml'))
	$messages[] = "Su servidor no tiene instalada la extensión <strong>php-xml</strong>, necesaria para instalar Inventario - UCV. Instale y habilite esta extensión antes de continuar.";

if(count($messages) > 0)
	return renderPage($messages);

// Comprobar que los archivos existen en la ubicación actual
if(!file_exists('index.php'))
	$messages[] = "Falta el archivo <strong>index.php</strong> en este directorio (público). Asegúrese de seguir las instrucciones de instalación incluidas en la documentación y de haber copiado todos los archivos necesarios.";

if(!file_exists('.htaccess'))
$messages[] = "<strong>.falta el archivo htaccess</strong> en este directorio (público). Asegúrese de seguir las instrucciones de instalación incluidas en la documentación y de haber copiado todos los archivos necesarios.";

// Asegúrese de que encontramos la carpeta de Inventario | UCV y el archivo Path.php principal
if(!is_dir('inventario_ucv')) {
	$messages[] = "Carpeta <strong>ucv</strong> no encontrada. Por favor, asegúrese de haberlo subido.";
	return renderPage($messages);
}

if(!file_exists('inventario_ucv/app/Config/Paths.php')) {
	$messages[] = "No se encontró el archivo <strong>ucv/app/Config/Paths.php</strong>. Por favor, asegúrese de haber subido todos los archivos.";
	return renderPage($messages);
}

if(!file_exists('inventario_ucv/.env')) {
	$messages[] = "No se encontró el archivo <strong>ucv/.env</strong>. Por favor, asegúrese de haber subido todos los archivos.";
	return renderPage($messages);
}

// Intenta obtener las variables .env que necesitaremos para hacer la conexión MySQLi
$env = [];
$envLines = file('inventario_ucv/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
foreach($envLines as $envLine) {
	if(strpos(trim($envLine), '#') === 0)
		continue;
	list($name, $value) = explode('=', $envLine, 2);
	$name = trim($name);
	$value = trim($value);
	$env[$name] = $value;
}

if(!isset($env['database.default.hostname'])
	|| !isset($env['database.default.database'])
	|| !isset($env['database.default.username'])
	|| !isset($env['database.default.password'])) {
	$messages[] = "Archivo <strong>ucv/.env</strong> no válido. Por favor, asegúrese de haberlo modificado correctamente.";
	return renderPage($messages);
}

// Intento de hacer la conexión MySQLi
$connection = new mysqli($env['database.default.hostname'],
	$env['database.default.username'],
	$env['database.default.password'],
	$env['database.default.database']);
if($connection->connect_errno) {
	$messages[] = "Error de conexión de MySQL, quizás sus credenciales de MySQL en el archivo .env sean incorrectas. MySQL dijo:" . $connection->connect_error;
	return renderPage($messages);
}

//Asegúrese de que el sistema no esté ya instalado
$tableExists = $connection->query("SHOW TABLES LIKE 'ucv_settings'");
if($tableExists === false) {
	$messages[] = "MySQL error: " . $connection->error;
	return renderPage($messages);
}
if($tableExists->num_rows >= 1) {
	$messages[] = "Parece que su sistema ya está instalado. Si está intentando hacer una instalación nueva, elimine	<strong>todas</strong> Inventario - UCV tablas en su base de datos MySQL.";
	return renderPage($messages);
}

// Obtenga consultas de instalación -- Asegúrese de que existan, por supuesto
if(!file_exists('install_queries.php')) {
	$messages[] = "<strong>install_queries.php</strong> archivo no encontrado. Para instalar Inventario	- UCV, por favor restaurar este archivo	";
	return renderPage($messages);
}

$is_installation = true;
require 'install_queries.php';

// ¡Ejecute la instalación!
foreach($install_queries as $queryStr) {
	$query = $connection->query($queryStr);

	if($query === false) {
		$messages[] = "Error de MySQL al ejecutar la instalación. MySQL dijo: " . $connection->error;
		return renderPage($messages);
	}
}

$uri = substr($_SERVER['REQUEST_URI'], 0, strrpos($_SERVER['REQUEST_URI'], '/') + 1);

$messages[] = "¡Excelente! Inventario - UCV ya está instalado. Estas son sus credenciales de administrador, ¡asegúrese de cambiarlas tan pronto como inicie sesión!<br /><br />Además, sería genial si pudiera eliminar <strong>install.php</strong> y <strong >install_queries.php</strong> archivos :)<br /><br />
</div>
<strong>Usuario:</strong> admin<br />
<strong>Password:</strong> 123456
<div class=\"text-center\"><a href=\"${uri}\"><strong>Ingresar</strong></a></div>";

renderPage($messages);

function renderPage($messages) {
?>
<html>
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<title>Inventario - UCV Instalacion</title>
		<!-- Aqui va el icon que esta con el nombre aa.ico -->
		<link rel="shortcut icon" href="aa.ico" type="image/x-icon">
		<script type="text/javascript" src="assets/js/jquery-3.6.0.min.js"></script>
		<script type="text/javascript" src="assets/js/popper-2.9.2.min.js"></script>
		<script type="text/javascript" src="assets/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>

		<link rel="stylesheet" href="assets/css/install.css" />
		<link rel="stylesheet" href="assets/bootstrap-4.6.0-dist/css/bootstrap.min.css" />
	</head>

	<body>
		<div id="app" class="full-height">
			<div class="container">
				<div class="row text-center">
					<div class="align-self-center mx-auto col-12">
						<div id="install-box" class="text-left mx-auto">
							<div class="logo text-center">
								<img src="assets/images/logo/logo.png">
							</div>

							<div>
								<?php
								foreach($messages as $message)
									echo "<br />{$message}<br />";
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
<?php
}
?>